package ua.deryblue.lr4;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr3.model.Student;
import ua.deryblue.lr4.repository.GenericRepository;

import java.io.IOException;
import java.util.logging.*;

public class Main {
    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        setupLogging();

        log.info("=== Старт програми (ЛР4: Generics та Collections) ===");

        try {
            // Repository<Student> (identity = id)
            GenericRepository<Student> studentRepo = new GenericRepository<>(s -> String.valueOf(s.getId()));
            // Repository<Car> (identity = vin)
            GenericRepository<Car> carRepo = new GenericRepository<>(Car::getVin);
            // Repository<BankAccount> (identity = iban)
            GenericRepository<BankAccount> accountRepo = new GenericRepository<>(BankAccount::getIban);

            // --- Students ---
            studentRepo.add(new Student(1, "Max", 95.0));
            studentRepo.add(new Student(2, "Oleh", 78.5));

            // Дублікати (той самий identity)
            studentRepo.add(new Student(1, "Max Duplicate", 60.0));

            long sDup = studentRepo.countByIdentity("1");
            log.info("Students total=" + studentRepo.getAll().size() + ", duplicates for id=1 => " + sDup);

            String foundStudent = studentRepo.findByIdentity("1").map(Student::getName).orElse("NOT FOUND");
            log.info("Find student id=1 => " + foundStudent);

            studentRepo.removeByIdentity("1"); // видалить тільки перший збіг
            long sDupAfter = studentRepo.countByIdentity("1");
            log.info("After removeByIdentity(1): total=" + studentRepo.getAll().size()
                    + ", duplicates for id=1 => " + sDupAfter);

            // --- Cars ---
            carRepo.add(new Car("VIN-AAA", "Toyota", 7.2));
            carRepo.add(new Car("VIN-BBB", "Honda", 6.8));
            carRepo.add(new Car("VIN-AAA", "Toyota Duplicate", 7.1));

            long cDup = carRepo.countByIdentity("VIN-AAA");
            log.info("Cars total=" + carRepo.getAll().size() + ", duplicates for VIN-AAA => " + cDup);

            String foundCar = carRepo.findByIdentity("VIN-BBB").map(Car::getModel).orElse("NOT FOUND");
            log.info("Find car VIN-BBB => " + foundCar);

            // --- BankAccounts ---
            accountRepo.add(new BankAccount("UA-IBAN-001", "Dery BLUE", 1000));
            accountRepo.add(new BankAccount("UA-IBAN-002", "Olena", 250));
            accountRepo.add(new BankAccount("UA-IBAN-001", "Dery BLUE Duplicate", 50));

            long aDup = accountRepo.countByIdentity("UA-IBAN-001");
            log.info("Accounts total=" + accountRepo.getAll().size() + ", duplicates for UA-IBAN-001 => " + aDup);

            String foundAcc = accountRepo.findByIdentity("UA-IBAN-002").map(BankAccount::getOwner).orElse("NOT FOUND");
            log.info("Find account UA-IBAN-002 => " + foundAcc);

        } catch (InvalidDataException e) {
            log.severe("InvalidDataException: " + e.getMessage());
        } catch (Exception e) {
            log.severe("Unexpected error: " + e.getMessage());
        }

        log.info("=== Завершення програми ===");
    }

    private static void setupLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.ALL);

        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.ALL);
        }

        try {
            FileHandler fh = new FileHandler("app.log", true);
            fh.setLevel(Level.ALL);
            fh.setFormatter(new SimpleFormatter());
            root.addHandler(fh);
        } catch (IOException e) {
            root.warning("Не вдалося створити app.log: " + e.getMessage());
        }
    }
}
