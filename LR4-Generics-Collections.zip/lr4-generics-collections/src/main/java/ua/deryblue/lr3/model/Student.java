package ua.deryblue.lr3.model;

import ua.deryblue.lr3.exceptions.InvalidDataException;

import java.util.logging.Logger;

public class Student {
    private static final Logger log = Logger.getLogger(Student.class.getName());

    private final int id;
    private final String name;
    private final double grade; // 0..100

    public Student(int id, String name, double grade) throws InvalidDataException {
        if (id <= 0) throw new InvalidDataException("Student: id має бути > 0");
        if (name == null || name.trim().isEmpty()) throw new InvalidDataException("Student: name не може бути порожнім");
        if (grade < 0 || grade > 100) throw new InvalidDataException("Student: grade має бути в діапазоні 0..100");

        this.id = id;
        this.name = name.trim();
        this.grade = grade;

        log.info(() -> "Створено Student{id=" + id + ", name='" + this.name + "', grade=" + grade + "}");
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getGrade() { return grade; }

    public boolean isExcellent() {
        return grade >= 90.0;
    }
}
