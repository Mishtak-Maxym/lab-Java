package ua.deryblue.lr3;

import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;

import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {

    @Test
    void depositWithdraw_ok() throws InvalidDataException {
        BankAccount acc = new BankAccount("UA1", "Owner", 100);
        acc.deposit(50);
        acc.withdraw(30);
        assertEquals(120, acc.getBalance(), 1e-9);
    }

    @Test
    void withdrawTooMuch_throws() throws InvalidDataException {
        BankAccount acc = new BankAccount("UA1", "Owner", 100);
        assertThrows(InvalidDataException.class, () -> acc.withdraw(1000));
    }
}
