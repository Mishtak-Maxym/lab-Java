package ua.deryblue.lr3;

import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Car;

import static org.junit.jupiter.api.Assertions.*;

public class CarTest {

    @Test
    void fuelForTrip_ok() throws InvalidDataException {
        Car car = new Car("VIN1", "Model", 10);
        assertEquals(25.0, car.fuelForTrip(250), 1e-9);
    }

    @Test
    void fuelForTrip_negativeKm_throws() throws InvalidDataException {
        Car car = new Car("VIN1", "Model", 10);
        assertThrows(InvalidDataException.class, () -> car.fuelForTrip(-1));
    }
}
