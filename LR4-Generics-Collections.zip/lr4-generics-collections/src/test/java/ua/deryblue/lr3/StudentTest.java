package ua.deryblue.lr3;

import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Student;

import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {

    @Test
    void createStudent_ok() {
        assertDoesNotThrow(() -> new Student(1, "Test", 90));
    }

    @Test
    void createStudent_invalidGrade_throws() {
        assertThrows(InvalidDataException.class, () -> new Student(1, "Test", 200));
    }

    @Test
    void isExcellent_logic() throws InvalidDataException {
        Student s = new Student(1, "A", 95);
        assertTrue(s.isExcellent());
    }
}
