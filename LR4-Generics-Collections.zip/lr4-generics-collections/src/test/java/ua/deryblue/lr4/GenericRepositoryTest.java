package ua.deryblue.lr4;

import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr3.model.Student;
import ua.deryblue.lr4.repository.GenericRepository;

import static org.junit.jupiter.api.Assertions.*;

class GenericRepositoryTest {

    @Test
    void addAndGetAllWorks() throws InvalidDataException {
        var repo = new GenericRepository<Student>(s -> String.valueOf(s.getId()));

        repo.add(new Student(1, "Max", 95.0));
        repo.add(new Student(2, "Oleh", 70.0));

        assertEquals(2, repo.getAll().size());
        assertEquals("Max", repo.getAll().get(0).getName());
    }

    @Test
    void findByIdentityWorks() throws InvalidDataException {
        var repo = new GenericRepository<Car>(Car::getVin);
        repo.add(new Car("VIN-1", "Toyota", 7.0));

        assertTrue(repo.findByIdentity("VIN-1").isPresent());
        assertTrue(repo.findByIdentity("VIN-X").isEmpty());
    }

    @Test
    void duplicatesAllowed_countAndRemoveFirst() throws InvalidDataException {
        var repo = new GenericRepository<Student>(s -> String.valueOf(s.getId()));

        repo.add(new Student(1, "A", 90.0));
        repo.add(new Student(1, "B", 60.0));
        repo.add(new Student(1, "C", 75.0));

        assertEquals(3, repo.getAll().size());
        assertEquals(3, repo.countByIdentity("1"));

        // find => перший елемент з таким id
        assertEquals("A", repo.findByIdentity("1").orElseThrow().getName());

        // removeByIdentity => видаляє лише перший збіг
        assertTrue(repo.removeByIdentity("1"));
        assertEquals(2, repo.getAll().size());
        assertEquals(2, repo.countByIdentity("1"));
        assertEquals("B", repo.findByIdentity("1").orElseThrow().getName());
    }

    @Test
    void invalidArgsThrowInvalidDataException() {
        assertThrows(InvalidDataException.class, () -> new GenericRepository<Student>(null));

        assertThrows(InvalidDataException.class, () -> {
            var repo = new GenericRepository<Student>(s -> String.valueOf(s.getId()));
            repo.add(null);
        });

        assertThrows(InvalidDataException.class, () -> {
            var repo = new GenericRepository<Student>(s -> String.valueOf(s.getId()));
            repo.findByIdentity(" ");
        });
    }
}
