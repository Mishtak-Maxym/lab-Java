# ЛР 4: Generics та Collections (Java)

Проєкт демонструє:
- використання класів з ЛР3 (`Student`, `Car`, `BankAccount`) та власного виключення `InvalidDataException`;
- параметризовані типи (Generics) через `GenericRepository<T>`;
- роботу з колекціями (`List<T>`) — додавання, видалення, отримання всіх елементів;
- пошук об'єкта за унікальним полем `findByIdentity(...)` через функціональний інтерфейс `IdentityExtractor<T>` (лямбда або method reference);
- демонстрацію дублікованих даних (однаковий identity) + `removeByIdentity(...)` видаляє перший збіг;
- логування основних операцій;
- юніт-тести JUnit 5 для репозиторію та моделей.

## Структура
- `ua.deryblue.lr4.repository.IdentityExtractor`
- `ua.deryblue.lr4.repository.GenericRepository`
- `ua.deryblue.lr4.Main`

## Запуск
```bash
mvn test
mvn exec:java
```

Main class: `ua.deryblue.lr4.Main`
