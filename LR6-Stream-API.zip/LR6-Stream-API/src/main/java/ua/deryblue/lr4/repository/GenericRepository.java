package ua.deryblue.lr4.repository;

import ua.deryblue.lr3.exceptions.InvalidDataException;

import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Stream;

public class GenericRepository<T> {
    private static final Logger log = Logger.getLogger(GenericRepository.class.getName());

    private final List<T> items = new ArrayList<>();
    private final IdentityExtractor<T> identityExtractor;

    public GenericRepository(IdentityExtractor<T> identityExtractor) throws InvalidDataException {
        if (identityExtractor == null) {
            throw new InvalidDataException("IdentityExtractor не може бути null");
        }
        this.identityExtractor = identityExtractor;
    }

    public void add(T item) throws InvalidDataException {
        validateItem(item);
        items.add(item);
        try {
            log.info(() -> "ADD: id=" + safeIdentity(item) + ", total=" + items.size());
        } catch (RuntimeException e) {
            // на випадок, якщо екстрактор працює нестабільно
            throw new InvalidDataException("Помилка при витягуванні identity: " + e.getMessage(), e);
        }
    }

    public boolean remove(T item) {
        if (item == null) {
            return false;
        }
        boolean removed = items.remove(item);
        log.info(() -> "REMOVE: removed=" + removed + ", total=" + items.size());
        return removed;
    }

    /**
     * Видаляє перший елемент з таким identity.
     * Це дозволяє показати роботу з дублікатами (інші дублікати можуть залишитися).
     */
    public boolean removeByIdentity(String identity) throws InvalidDataException {
        validateIdentity(identity);
        try {
            for (Iterator<T> it = items.iterator(); it.hasNext(); ) {
                T cur = it.next();
                if (identity.equals(safeIdentity(cur))) {
                    it.remove();
                    log.info(() -> "REMOVE_BY_ID: id=" + identity + ", total=" + items.size());
                    return true;
                }
            }
        } catch (RuntimeException e) {
            throw new InvalidDataException("Помилка при витягуванні identity: " + e.getMessage(), e);
        }
        log.info(() -> "REMOVE_BY_ID: id=" + identity + " (not found)");
        return false;
    }

    public List<T> getAll() {
        return List.copyOf(items);
    }

    /**
     * Stream over internal storage.
     * Використовується у спеціалізованих репозиторіях (ЛР6) для пошуку через Stream API.
     */
    public Stream<T> stream() {
        return items.stream();
    }

    /**
     * Parallel stream over internal storage.
     * Використовується для демонстрації продуктивності stream vs parallelStream.
     */
    public Stream<T> parallelStream() {
        return items.parallelStream();
    }

    public Optional<T> findByIdentity(String identity) throws InvalidDataException {
        validateIdentity(identity);
        try {
            Optional<T> found = items.stream()
                    .filter(x -> confirmsIdentity(x, identity))
                    .findFirst();

            log.info(() -> "FIND: id=" + identity + ", found=" + found.isPresent());
            return found;
        } catch (RuntimeException e) {
            throw new InvalidDataException("Помилка при пошуку за identity: " + e.getMessage(), e);
        }
    }

    public long countByIdentity(String identity) throws InvalidDataException {
        validateIdentity(identity);
        try {
            return items.stream().filter(x -> confirmsIdentity(x, identity)).count();
        } catch (RuntimeException e) {
            throw new InvalidDataException("Помилка при підрахунку за identity: " + e.getMessage(), e);
        }
    }

    private boolean confirmsIdentity(T item, String identity) {
        return identity.equals(safeIdentity(item));
    }

    private void validateItem(T item) throws InvalidDataException {
        if (item == null) {
            throw new InvalidDataException("Елемент не може бути null");
        }
        try {
            String id = safeIdentity(item);
            if (id == null || id.isBlank()) {
                throw new InvalidDataException("Identity не може бути порожнім");
            }
        } catch (RuntimeException e) {
            throw new InvalidDataException("Помилка при витягуванні identity: " + e.getMessage(), e);
        }
    }

    private void validateIdentity(String identity) throws InvalidDataException {
        if (identity == null || identity.isBlank()) {
            throw new InvalidDataException("Параметр identity не може бути null/blank");
        }
    }

    private String safeIdentity(T item) {
        try {
            return identityExtractor.getIdentity(item);
        } catch (Exception e) {
            throw new RuntimeException("Помилка при витягуванні identity: " + e.getMessage(), e);
        }
    }
}
