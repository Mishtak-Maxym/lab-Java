package ua.deryblue.lr6.repository;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;
import ua.deryblue.lr4.repository.GenericRepository;

import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

/**
 * Спеціалізований репозиторій для BankAccount.
 */
public class BankAccountRepository extends GenericRepository<BankAccount> {
    private static final Logger log = Logger.getLogger(BankAccountRepository.class.getName());

    public BankAccountRepository() throws InvalidDataException {
        super(BankAccount::getIban);
    }

    public List<BankAccount> findByOwnerContains(String part) {
        log.info(() -> "BankAccountRepository.findByOwnerContains(part=" + part + ")");
        if (part == null || part.isBlank()) return List.of();

        String p = part.trim().toLowerCase(Locale.ROOT);
        return stream()
                .filter(a -> a.getOwner() != null && a.getOwner().toLowerCase(Locale.ROOT).contains(p))
                .toList();
    }

    public List<BankAccount> findByBalanceRange(double min, double max) {
        log.info(() -> "BankAccountRepository.findByBalanceRange(min=" + min + ", max=" + max + ")");
        if (min > max) return List.of();

        return stream()
                .filter(a -> a.getBalance() >= min && a.getBalance() <= max)
                .toList();
    }

    /**
     * map: список усіх IBAN.
     */
    public List<String> getAllIbans() {
        log.info("BankAccountRepository.getAllIbans()");
        return stream()
                .map(BankAccount::getIban)
                .filter(i -> i != null && !i.isBlank())
                .toList();
    }

    /**
     * reduce: загальна сума коштів на всіх рахунках.
     */
    public double totalBalance() {
        log.info("BankAccountRepository.totalBalance()");
        return stream()
                .map(BankAccount::getBalance)
                .reduce(0.0, Double::sum);
    }
}
