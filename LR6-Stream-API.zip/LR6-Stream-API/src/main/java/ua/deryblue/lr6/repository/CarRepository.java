package ua.deryblue.lr6.repository;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr4.repository.GenericRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

/**
 * Спеціалізований репозиторій для Car.
 */
public class CarRepository extends GenericRepository<Car> {
    private static final Logger log = Logger.getLogger(CarRepository.class.getName());

    public CarRepository() throws InvalidDataException {
        super(Car::getVin);
    }

    public List<Car> findByModelContains(String part) {
        log.info(() -> "CarRepository.findByModelContains(part=" + part + ")");
        if (part == null || part.isBlank()) return List.of();

        String p = part.trim().toLowerCase(Locale.ROOT);
        return stream()
                .filter(c -> c.getModel() != null && c.getModel().toLowerCase(Locale.ROOT).contains(p))
                .toList();
    }

    public List<Car> findByFuelConsumptionRange(double min, double max) {
        log.info(() -> "CarRepository.findByFuelConsumptionRange(min=" + min + ", max=" + max + ")");
        if (min > max) return List.of();

        return stream()
                .filter(c -> c.getFuelConsumption() >= min && c.getFuelConsumption() <= max)
                .toList();
    }

    /**
     * flatMap: унікальні токени зі всіх назв моделей ("Toyota Camry" -> [toyota, camry]).
     */
    public List<String> getAllModelTokens() {
        log.info("CarRepository.getAllModelTokens()");
        return stream()
                .map(Car::getModel)
                .filter(m -> m != null && !m.isBlank())
                .map(m -> m.trim().split("\\s+"))
                .flatMap(Arrays::stream)
                .map(t -> t.toLowerCase(Locale.ROOT))
                .distinct()
                .toList();
    }
}
