package ua.deryblue.lr6.repository;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Student;
import ua.deryblue.lr4.repository.GenericRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

/**
 * Спеціалізований репозиторій для Student.
 * Розширює базовий GenericRepository<Student>.
 */
public class StudentRepository extends GenericRepository<Student> {
    private static final Logger log = Logger.getLogger(StudentRepository.class.getName());

    public StudentRepository() throws InvalidDataException {
        super(s -> String.valueOf(s.getId()));
    }

    public List<Student> findByNameContains(String part) {
        log.info(() -> "StudentRepository.findByNameContains(part=" + part + ")");
        if (part == null || part.isBlank()) return List.of();

        String p = part.trim().toLowerCase(Locale.ROOT);
        return stream()
                .filter(s -> s.getName() != null && s.getName().toLowerCase(Locale.ROOT).contains(p))
                .toList(); // collect/toList
    }

    public List<Student> findByGradeRange(double min, double max) {
        log.info(() -> "StudentRepository.findByGradeRange(min=" + min + ", max=" + max + ")");
        if (min > max) return List.of();

        return stream()
                .filter(s -> s.getGrade() >= min && s.getGrade() <= max)
                .toList();
    }

    /**
     * map + collect: всі імена у верхньому регістрі.
     */
    public List<String> getNamesUppercase() {
        log.info("StudentRepository.getNamesUppercase()");
        return stream()
                .map(Student::getName)
                .filter(n -> n != null && !n.isBlank())
                .map(n -> n.toUpperCase(Locale.ROOT))
                .toList();
    }

    /**
     * flatMap: розбиває fullName на токени (слова) і повертає унікальні.
     */
    public List<String> getAllNameTokens() {
        log.info("StudentRepository.getAllNameTokens()");
        return stream()
                .map(Student::getName)
                .filter(n -> n != null && !n.isBlank())
                .map(n -> n.trim().split("\\s+"))
                .flatMap(Arrays::stream)
                .map(t -> t.toLowerCase(Locale.ROOT))
                .distinct()
                .toList();
    }

    /**
     * reduce: сума всіх оцінок.
     */
    public double totalGrades() {
        log.info("StudentRepository.totalGrades()");
        return stream()
                .map(Student::getGrade)
                .reduce(0.0, Double::sum);
    }
}
