package ua.deryblue.lr6;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr3.model.Student;
import ua.deryblue.lr6.repository.BankAccountRepository;
import ua.deryblue.lr6.repository.CarRepository;
import ua.deryblue.lr6.repository.StudentRepository;

import java.io.IOException;
import java.util.logging.*;

public class Main {
    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        setupLogging();
        log.info("=== Старт програми (ЛР6: Stream API) ===");

        try {
            StudentRepository students = new StudentRepository();
            CarRepository cars = new CarRepository();
            BankAccountRepository accounts = new BankAccountRepository();

            // --- Додаємо сутності ---
            students.add(new Student(1, "Max Dery", 95.0));
            students.add(new Student(2, "Oleh Petrenko", 78.5));
            students.add(new Student(3, "Ivan Shevchenko", 88.0));

            cars.add(new Car("VIN-AAA", "Toyota Camry", 7.2));
            cars.add(new Car("VIN-BBB", "Honda Civic", 6.8));
            cars.add(new Car("VIN-CCC", "Toyota Corolla", 6.4));

            accounts.add(new BankAccount("UA-IBAN-001", "Dery BLUE", 1000));
            accounts.add(new BankAccount("UA-IBAN-002", "Olena", 250));
            accounts.add(new BankAccount("UA-IBAN-003", "Ivan Petrenko", 8000));

            // --- Пошук через Stream API (filter) + forEach (термінальна) ---
            System.out.println("\n--- Students: name contains 'iv' ---");
            students.findByNameContains("iv")
                    .forEach(s -> System.out.println("Student{id=" + s.getId() + ", name='" + s.getName() + "', grade=" + s.getGrade() + "}"));

            System.out.println("\n--- Students: grade range 80..100 ---");
            students.findByGradeRange(80, 100)
                    .forEach(s -> System.out.println("Student{id=" + s.getId() + ", name='" + s.getName() + "', grade=" + s.getGrade() + "}"));

            System.out.println("\n--- Cars: model contains 'toyota' ---");
            cars.findByModelContains("toyota")
                    .forEach(c -> System.out.println("Car{vin='" + c.getVin() + "', model='" + c.getModel() + "', fuel=" + c.getFuelConsumption() + "}"));

            System.out.println("\n--- Accounts: owner contains 'iv' ---");
            accounts.findByOwnerContains("iv")
                    .forEach(a -> System.out.println("BankAccount{iban='" + a.getIban() + "', owner='" + a.getOwner() + "', balance=" + a.getBalance() + "}"));

            // --- map + collect ---
            System.out.println("\nNames UPPERCASE = " + students.getNamesUppercase());
            System.out.println("All IBANs = " + accounts.getAllIbans());

            // --- flatMap приклади ---
            System.out.println("\nStudent name tokens = " + students.getAllNameTokens());
            System.out.println("Car model tokens = " + cars.getAllModelTokens());

            // --- reduce приклади ---
            System.out.println("\nTotal students grades (reduce) = " + students.totalGrades());
            System.out.println("Total balance (reduce) = " + accounts.totalBalance());

            // --- Порівняння stream vs parallelStream (на великій кількості даних) ---
            BankAccountRepository bigRepo = new BankAccountRepository();
            for (int i = 1; i <= 200_000; i++) {
                bigRepo.add(new BankAccount("UA-TEST-" + i, "User" + i, i % 1000));
            }

            long t1 = System.nanoTime();
            double sumSeq = bigRepo.stream().mapToDouble(BankAccount::getBalance).sum();
            long t2 = System.nanoTime();

            long t3 = System.nanoTime();
            double sumPar = bigRepo.parallelStream().mapToDouble(BankAccount::getBalance).sum();
            long t4 = System.nanoTime();

            System.out.println("\n--- Performance (200_000 accounts) ---");
            System.out.println("sequential sum = " + sumSeq + ", time ms = " + (t2 - t1) / 1_000_000);
            System.out.println("parallel   sum = " + sumPar + ", time ms = " + (t4 - t3) / 1_000_000);

        } catch (InvalidDataException e) {
            log.severe("InvalidDataException: " + e.getMessage());
        } catch (Exception e) {
            log.severe("Unexpected error: " + e.getMessage());
        }

        log.info("=== Завершення програми ===");
    }

    private static void setupLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.ALL);

        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.ALL);
        }

        try {
            FileHandler fh = new FileHandler("app.log", true);
            fh.setLevel(Level.ALL);
            fh.setFormatter(new SimpleFormatter());
            root.addHandler(fh);
        } catch (IOException e) {
            root.warning("Не вдалося створити app.log: " + e.getMessage());
        }
    }
}
