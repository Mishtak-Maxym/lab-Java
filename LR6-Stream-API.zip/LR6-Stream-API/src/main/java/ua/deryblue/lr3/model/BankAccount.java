package ua.deryblue.lr3.model;

import ua.deryblue.lr3.exceptions.InvalidDataException;

import java.util.logging.Logger;

public class BankAccount {
    private static final Logger log = Logger.getLogger(BankAccount.class.getName());

    private final String iban;
    private final String owner;
    private double balance;

    public BankAccount(String iban, String owner, double balance) throws InvalidDataException {
        if (iban == null || iban.trim().isEmpty()) throw new InvalidDataException("BankAccount: iban не може бути порожнім");
        if (owner == null || owner.trim().isEmpty()) throw new InvalidDataException("BankAccount: owner не може бути порожнім");
        if (balance < 0) throw new InvalidDataException("BankAccount: balance не може бути < 0");

        this.iban = iban.trim();
        this.owner = owner.trim();
        this.balance = balance;

        log.info(() -> "Створено BankAccount{iban='" + this.iban + "', owner='" + this.owner + "', balance=" + balance + "}");
    }

    public String getIban() { return iban; }
    public String getOwner() { return owner; }
    public double getBalance() { return balance; }

    public void deposit(double amount) throws InvalidDataException {
        if (amount <= 0) throw new InvalidDataException("Deposit: amount має бути > 0");
        balance += amount;
        log.info(() -> "Deposit " + amount + " -> balance=" + balance);
    }

    public void withdraw(double amount) throws InvalidDataException {
        if (amount <= 0) throw new InvalidDataException("Withdraw: amount має бути > 0");
        if (amount > balance) throw new InvalidDataException("Withdraw: недостатньо коштів (balance=" + balance + ")");
        balance -= amount;
        log.info(() -> "Withdraw " + amount + " -> balance=" + balance);
    }
}
