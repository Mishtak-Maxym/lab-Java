package ua.deryblue.lr3.io;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr3.model.Student;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class CsvDataLoader {
    private static final Logger log = Logger.getLogger(CsvDataLoader.class.getName());

    private CsvDataLoader() {}

    public static List<Student> loadStudents(String filePath)
            throws FileNotFoundException, IOException, InvalidDataException {
        return load(filePath, CsvDataLoader::parseStudent);
    }

    public static List<Car> loadCars(String filePath)
            throws FileNotFoundException, IOException, InvalidDataException {
        return load(filePath, CsvDataLoader::parseCar);
    }

    public static List<BankAccount> loadAccounts(String filePath)
            throws FileNotFoundException, IOException, InvalidDataException {
        return load(filePath, CsvDataLoader::parseAccount);
    }

    @FunctionalInterface
    private interface LineParser<T> {
        T parse(String line, int lineNo) throws InvalidDataException;
    }

    private static <T> List<T> load(String filePath, LineParser<T> parser)
            throws FileNotFoundException, IOException, InvalidDataException {

        BufferedReader br = null;
        List<T> list = new ArrayList<>();

        try {
            log.info(() -> "Початок читання файлу: " + filePath);
            br = new BufferedReader(new FileReader(filePath)); // FileNotFoundException

            String line;
            int lineNo = 0;

            while ((line = br.readLine()) != null) {
                lineNo++;
                String trimmed = line.trim();

                if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;

                T obj = parser.parse(trimmed, lineNo); // InvalidDataException
                list.add(obj);
            }

            log.info(() -> "Успішно прочитано: " + list.size() + " запис(ів) з " + filePath);
            return list;

        } catch (FileNotFoundException e) {
            log.log(Level.SEVERE, "Файл не знайдено: " + filePath, e);
            throw e;
        } catch (IOException e) {
            log.log(Level.SEVERE, "Помилка читання файлу: " + filePath, e);
            throw e;
        } finally {
            // Демонстрація try-catch-finally: ручне закриття ресурсу
            if (br != null) {
                try {
                    br.close();
                    log.info(() -> "Файл закрито: " + filePath);
                } catch (IOException e) {
                    log.log(Level.WARNING, "Не вдалося закрити файл: " + filePath, e);
                }
            }
        }
    }

    // Student: id;name;grade
    private static Student parseStudent(String line, int lineNo) throws InvalidDataException {
        try {
            String[] p = line.split(";");
            int id = Integer.parseInt(p[0].trim());
            String name = p[1].trim();
            double grade = Double.parseDouble(p[2].trim());
            return new Student(id, name, grade);
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) { // multi-catch
            throw new InvalidDataException("Некоректний рядок Student (line " + lineNo + "): " + line, e);
        }
    }

    // Car: vin;model;fuelConsumption
    private static Car parseCar(String line, int lineNo) throws InvalidDataException {
        try {
            String[] p = line.split(";");
            String vin = p[0].trim();
            String model = p[1].trim();
            double fuel = Double.parseDouble(p[2].trim());
            return new Car(vin, model, fuel);
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            throw new InvalidDataException("Некоректний рядок Car (line " + lineNo + "): " + line, e);
        }
    }

    // Account: iban;owner;balance
    private static BankAccount parseAccount(String line, int lineNo) throws InvalidDataException {
        try {
            String[] p = line.split(";");
            String iban = p[0].trim();
            String owner = p[1].trim();
            double balance = Double.parseDouble(p[2].trim());
            return new BankAccount(iban, owner, balance);
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            throw new InvalidDataException("Некоректний рядок Account (line " + lineNo + "): " + line, e);
        }
    }
}
