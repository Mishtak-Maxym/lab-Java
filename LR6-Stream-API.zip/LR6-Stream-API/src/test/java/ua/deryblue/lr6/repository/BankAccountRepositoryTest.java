package ua.deryblue.lr6.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.BankAccount;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountRepositoryTest {
    private BankAccountRepository repo;

    @BeforeEach
    void setUp() throws InvalidDataException {
        repo = new BankAccountRepository();
        repo.add(new BankAccount("UA-IBAN-001", "Dery BLUE", 1000));
        repo.add(new BankAccount("UA-IBAN-002", "Olena", 250));
        repo.add(new BankAccount("UA-IBAN-003", "Ivan Petrenko", 8000));
    }

    @Test
    void findByOwnerContains_shouldWorkCaseInsensitive() {
        var res = repo.findByOwnerContains("iv");
        assertEquals(1, res.size());
        assertEquals("UA-IBAN-003", res.get(0).getIban());
    }

    @Test
    void findByBalanceRange_shouldReturnInRange() {
        var res = repo.findByBalanceRange(200, 1200);
        assertEquals(2, res.size());
    }

    @Test
    void totalBalance_shouldUseReduce() {
        assertEquals(9250.0, repo.totalBalance(), 0.0001);
    }
}
