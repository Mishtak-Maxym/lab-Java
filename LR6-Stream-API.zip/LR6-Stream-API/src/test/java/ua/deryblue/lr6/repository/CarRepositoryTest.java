package ua.deryblue.lr6.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Car;

import static org.junit.jupiter.api.Assertions.*;

class CarRepositoryTest {
    private CarRepository repo;

    @BeforeEach
    void setUp() throws InvalidDataException {
        repo = new CarRepository();
        repo.add(new Car("VIN-AAA", "Toyota Camry", 7.2));
        repo.add(new Car("VIN-BBB", "Honda Civic", 6.8));
        repo.add(new Car("VIN-CCC", "Toyota Corolla", 6.4));
    }

    @Test
    void findByModelContains_shouldFilter() {
        var res = repo.findByModelContains("toyota");
        assertEquals(2, res.size());
    }

    @Test
    void findByFuelConsumptionRange_shouldWork() {
        var res = repo.findByFuelConsumptionRange(6.5, 7.5);
        assertEquals(2, res.size());
    }

    @Test
    void getAllModelTokens_shouldReturnDistinctTokens() {
        var tokens = repo.getAllModelTokens();
        assertTrue(tokens.contains("toyota"));
        assertTrue(tokens.contains("camry"));
        assertFalse(tokens.contains(""));
    }
}
