package ua.deryblue.lr6.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.model.Student;

import static org.junit.jupiter.api.Assertions.*;

class StudentRepositoryTest {
    private StudentRepository repo;

    @BeforeEach
    void setUp() throws InvalidDataException {
        repo = new StudentRepository();
        repo.add(new Student(1, "Max Dery", 95.0));
        repo.add(new Student(2, "Oleh Petrenko", 78.5));
        repo.add(new Student(3, "Ivan Shevchenko", 88.0));
        repo.add(new Student(4, "Ivan Ivanov", 65.0));
    }

    @Test
    void findByNameContains_shouldBeCaseInsensitive() {
        var res = repo.findByNameContains("IVAN");
        assertEquals(2, res.size());
    }

    @Test
    void findByGradeRange_shouldReturnOnlyInRange() {
        var res = repo.findByGradeRange(80, 100);
        assertEquals(2, res.size());
    }

    @Test
    void getAllNameTokens_shouldUseFlatMapAndDistinct() {
        var tokens = repo.getAllNameTokens();
        assertTrue(tokens.contains("ivan"));
        assertTrue(tokens.contains("petrenko"));
    }

    @Test
    void totalGrades_shouldUseReduce() {
        double total = repo.totalGrades();
        assertEquals(95.0 + 78.5 + 88.0 + 65.0, total, 0.0001);
    }
}
