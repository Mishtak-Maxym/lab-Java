package ua.deryblue.lr3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.io.CsvDataLoader;
import ua.deryblue.lr3.model.Student;

import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CsvDataLoaderTest {

    @TempDir
    Path tempDir;

    @Test
    void loadStudents_ok() throws Exception {
        Path f = tempDir.resolve("students.csv");
        Files.writeString(f, "1;Test;90\n2;Test2;80\n");

        List<Student> list = CsvDataLoader.loadStudents(f.toString());
        assertEquals(2, list.size());
        assertEquals("Test", list.get(0).getName());
    }

    @Test
    void loadStudents_invalidLine_throws() throws Exception {
        Path f = tempDir.resolve("students.csv");
        Files.writeString(f, "1;Test;NOT_A_NUMBER\n");

        assertThrows(InvalidDataException.class, () -> CsvDataLoader.loadStudents(f.toString()));
    }

    @Test
    void loadStudents_fileNotFound_throws() {
        assertThrows(FileNotFoundException.class, () -> CsvDataLoader.loadStudents("no_such_file.csv"));
    }
}
