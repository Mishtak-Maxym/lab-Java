package ua.deryblue.lr3;

import ua.deryblue.lr3.exceptions.InvalidDataException;
import ua.deryblue.lr3.io.CsvDataLoader;
import ua.deryblue.lr3.model.BankAccount;
import ua.deryblue.lr3.model.Car;
import ua.deryblue.lr3.model.Student;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.logging.*;

public class Main {
    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        setupLogging();

        String studentsPath = "src/main/resources/data/students.csv";
        String carsPath = "src/main/resources/data/cars.csv";
        String accountsPath = "src/main/resources/data/accounts.csv";

        log.info("=== Старт програми (ЛР3: Виключення, Файли, Логування) ===");

        try {
            List<Student> students = CsvDataLoader.loadStudents(studentsPath);
            log.info(() -> "Перший студент: " + students.get(0).getName()
                    + ", excellent=" + students.get(0).isExcellent());
        } catch (FileNotFoundException e) {
            log.severe("students.csv не знайдено: " + e.getMessage());
        } catch (InvalidDataException e) {
            log.severe("Некоректні дані у students.csv: " + e.getMessage());
        } catch (IOException e) {
            log.severe("IO помилка при читанні students.csv: " + e.getMessage());
        }

        try {
            List<Car> cars = CsvDataLoader.loadCars(carsPath);
            double liters = cars.get(0).fuelForTrip(250);
            log.info(() -> "Car trip fuel (250km): " + liters);
        } catch (FileNotFoundException e) {
            log.severe("cars.csv не знайдено: " + e.getMessage());
        } catch (InvalidDataException | IllegalArgumentException e) { // multi-catch
            log.severe("Помилка даних/логіки при роботі з авто: " + e.getMessage());
        } catch (IOException e) {
            log.severe("IO помилка при читанні cars.csv: " + e.getMessage());
        }

        try {
            List<BankAccount> accounts = CsvDataLoader.loadAccounts(accountsPath);
            BankAccount acc = accounts.get(0);
            acc.deposit(1000);
            acc.withdraw(200);
            log.info(() -> "Account balance after ops: " + acc.getBalance());
        } catch (FileNotFoundException e) {
            log.severe("accounts.csv не знайдено: " + e.getMessage());
        } catch (InvalidDataException e) {
            log.severe("Некоректні дані/операція з рахунком: " + e.getMessage());
        } catch (IOException e) {
            log.severe("IO помилка при читанні accounts.csv: " + e.getMessage());
        }

        log.info("=== Завершення програми ===");
    }

    private static void setupLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.ALL);

        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.ALL);
        }

        try {
            FileHandler fh = new FileHandler("app.log", true);
            fh.setLevel(Level.ALL);
            fh.setFormatter(new SimpleFormatter());
            root.addHandler(fh);
        } catch (IOException e) {
            root.warning("Не вдалося створити app.log: " + e.getMessage());
        }
    }
}
