package ua.deryblue.lr3.model;

import ua.deryblue.lr3.exceptions.InvalidDataException;

import java.util.logging.Logger;

public class Car {
    private static final Logger log = Logger.getLogger(Car.class.getName());

    private final String vin;
    private final String model;
    private final double fuelConsumption; // liters per 100 km

    public Car(String vin, String model, double fuelConsumption) throws InvalidDataException {
        if (vin == null || vin.trim().isEmpty()) throw new InvalidDataException("Car: vin не може бути порожнім");
        if (model == null || model.trim().isEmpty()) throw new InvalidDataException("Car: model не може бути порожнім");
        if (fuelConsumption <= 0) throw new InvalidDataException("Car: fuelConsumption має бути > 0");

        this.vin = vin.trim();
        this.model = model.trim();
        this.fuelConsumption = fuelConsumption;

        log.info(() -> "Створено Car{vin='" + this.vin + "', model='" + this.model + "', fuel=" + fuelConsumption + "}");
    }

    public String getVin() { return vin; }
    public String getModel() { return model; }
    public double getFuelConsumption() { return fuelConsumption; }

    public double fuelForTrip(double km) throws InvalidDataException {
        if (km < 0) throw new InvalidDataException("Car: km не може бути від’ємним");
        return (fuelConsumption / 100.0) * km;
    }
}
