# ЛР 3: Обробка виключень (Java)

Проєкт демонструє:
- власний клас виключення `InvalidDataException`;
- зчитування даних з файлів (CSV) + обробку помилок (FileNotFoundException, IOException, InvalidDataException);
- використання `try-catch-finally` та `multi-catch`;
- логування критичних та інформаційних подій (консоль + файл `app.log`);
- базові тести (JUnit 5).

## Структура даних (CSV)
- `students.csv`: `id;name;grade`
- `cars.csv`: `vin;model;fuelConsumption`
- `accounts.csv`: `iban;owner;balance`

## Запуск
```bash
mvn test
mvn exec:java
```
