package ua.bank.model;

import java.util.Objects;
import ua.util.Utils;

/**
 * Base class to demonstrate protected access.
 */
public abstract class Person {
    protected String firstName;
    protected String lastName;

    protected Person(String firstName, String lastName) {
        this.firstName = Utils.requireNonBlank(firstName, "firstName");
        this.lastName = Utils.requireNonBlank(lastName, "lastName");
    }

    public String getFirstName() { return firstName; }

    public void setFirstName(String firstName) {
        this.firstName = Utils.requireNonBlank(firstName, "firstName");
    }

    public String getLastName() { return lastName; }

    public void setLastName(String lastName) {
        this.lastName = Utils.requireNonBlank(lastName, "lastName");
    }

    protected String fullName() { return firstName + " " + lastName; }

    @Override
    public String toString() {
        return "Person{firstName='%s', lastName='%s'}".formatted(firstName, lastName);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person person)) return false;
        return Objects.equals(firstName, person.firstName) && Objects.equals(lastName, person.lastName);
    }

    @Override
    public int hashCode() { return Objects.hash(firstName, lastName); }
}
