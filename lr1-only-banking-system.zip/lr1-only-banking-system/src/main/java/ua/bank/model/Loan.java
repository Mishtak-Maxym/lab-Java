package ua.bank.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;
import ua.util.Utils;

public class Loan {
    private final Customer customer;
    private final BigDecimal amount;
    private final BigDecimal interestRatePercent;
    private final LocalDate startDate;

    public Loan(Customer customer, BigDecimal amount, BigDecimal interestRatePercent, LocalDate startDate) {
        this.customer = Utils.requireNonNull(customer, "customer");
        this.amount = Utils.money(Utils.requirePositive(amount, "amount"));
        this.interestRatePercent = Utils.requireRatePercent(interestRatePercent, "interestRate");
        this.startDate = Utils.requireNonNull(startDate, "startDate");
    }

    public static Loan of(Customer customer, BigDecimal amount, BigDecimal interestRatePercent, LocalDate startDate) {
        return new Loan(customer, amount, interestRatePercent, startDate);
    }

    public Customer getCustomer() { return customer; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getInterestRatePercent() { return interestRatePercent; }
    public LocalDate getStartDate() { return startDate; }

    public BigDecimal estimateOneYearInterest() {
        return Utils.money(amount.multiply(interestRatePercent).divide(new BigDecimal("100")));
    }

    // package-private method (no modifier)
    String internalAuditInfo() {
        return "AUDIT: %s|%s|%s".formatted(customer.getEmail(), amount.toPlainString(), interestRatePercent.toPlainString());
    }

    @Override
    public String toString() {
        return "Loan{customer='%s', amount=%s, interestRate=%s%%, startDate=%s}"
                .formatted(customer.getFullName(), Utils.formatMoney(amount), interestRatePercent.toPlainString(), startDate);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Loan loan)) return false;
        return Objects.equals(customer, loan.customer)
                && Objects.equals(amount, loan.amount)
                && Objects.equals(interestRatePercent, loan.interestRatePercent)
                && Objects.equals(startDate, loan.startDate);
    }

    @Override
    public int hashCode() { return Objects.hash(customer, amount, interestRatePercent, startDate); }
}
