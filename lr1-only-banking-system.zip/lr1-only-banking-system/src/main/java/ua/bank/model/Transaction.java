package ua.bank.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import ua.util.Utils;

public class Transaction {
    private final Account fromAccount;
    private final Account toAccount;
    private final BigDecimal amount;
    private final LocalDateTime date;

    private Transaction(Account fromAccount, Account toAccount, BigDecimal amount, LocalDateTime date) {
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = Utils.money(Utils.requirePositive(amount, "amount"));
        this.date = Utils.requireNonNull(date, "date");

        // Validation without enums/switch:
        // deposit: from == null, to != null
        // withdrawal: from != null, to == null
        // transfer/payment: both != null
        boolean isDeposit = fromAccount == null && toAccount != null;
        boolean isWithdrawal = fromAccount != null && toAccount == null;
        boolean isTransfer = fromAccount != null && toAccount != null;

        Utils.require(isDeposit || isWithdrawal || isTransfer,
                "Invalid transaction: specify either toAccount (deposit), fromAccount (withdrawal), or both (transfer)");
    }

    // Factory methods
    public static Transaction deposit(Account to, BigDecimal amount) {
        return new Transaction(null, Utils.requireNonNull(to, "toAccount"), amount, Utils.now());
    }

    public static Transaction withdraw(Account from, BigDecimal amount) {
        return new Transaction(Utils.requireNonNull(from, "fromAccount"), null, amount, Utils.now());
    }

    public static Transaction transfer(Account from, Account to, BigDecimal amount) {
        return new Transaction(Utils.requireNonNull(from, "fromAccount"), Utils.requireNonNull(to, "toAccount"), amount, Utils.now());
    }

    public Account getFromAccount() { return fromAccount; }
    public Account getToAccount() { return toAccount; }
    public BigDecimal getAmount() { return amount; }
    public LocalDateTime getDate() { return date; }

    public String getKind() {
        if (fromAccount == null) return "DEPOSIT";
        if (toAccount == null) return "WITHDRAWAL";
        return "TRANSFER";
    }

    @Override
    public String toString() {
        String from = (fromAccount == null) ? "-" : fromAccount.getAccountNumber();
        String to = (toAccount == null) ? "-" : toAccount.getAccountNumber();
        return "Transaction{kind=%s, from='%s', to='%s', amount=%s, date=%s}"
                .formatted(getKind(), from, to, Utils.formatMoney(amount), date);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Transaction that)) return false;
        return Objects.equals(fromAccount, that.fromAccount)
                && Objects.equals(toAccount, that.toAccount)
                && Objects.equals(amount, that.amount)
                && Objects.equals(date, that.date);
    }

    @Override
    public int hashCode() { return Objects.hash(fromAccount, toAccount, amount, date); }
}
