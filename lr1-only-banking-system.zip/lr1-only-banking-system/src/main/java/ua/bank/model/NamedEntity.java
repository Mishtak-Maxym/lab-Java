package ua.bank.model;

import java.util.Objects;
import ua.util.Utils;

/**
 * Base class to show protected field + super().
 */
public abstract class NamedEntity {
    protected String name;

    protected NamedEntity(String name) {
        this.name = Utils.requireNonBlank(name, "name");
    }

    public String getName() { return name; }

    public void setName(String name) {
        this.name = Utils.requireNonBlank(name, "name");
    }

    protected String nameUpper() { return name.toUpperCase(); }

    @Override
    public String toString() { return "NamedEntity{name='%s'}".formatted(name); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NamedEntity that)) return false;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() { return Objects.hash(name); }
}
