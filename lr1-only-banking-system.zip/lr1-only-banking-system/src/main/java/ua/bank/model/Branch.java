package ua.bank.model;

import java.util.Objects;
import ua.util.Utils;

public class Branch extends NamedEntity {
    private String location;

    public Branch(String name, String location) {
        super(name);
        this.location = Utils.requireNonBlank(location, "location");
    }

    public static Branch of(String name, String location) { return new Branch(name, location); }

    public String getLocation() { return location; }

    public void setLocation(String location) { this.location = Utils.requireNonBlank(location, "location"); }

    @Override
    public String toString() { return "Branch{name='%s', location='%s'}".formatted(name, location); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Branch branch)) return false;
        return Objects.equals(name, branch.name) && Objects.equals(location, branch.location);
    }

    @Override
    public int hashCode() { return Objects.hash(name, location); }
}
