package ua.bank.model;

import java.util.Objects;
import ua.util.Utils;

public class Customer extends Person {
    private String email;

    public Customer(String firstName, String lastName, String email) {
        super(firstName, lastName);
        this.email = Utils.requireEmail(email);
    }

    public static Customer of(String firstName, String lastName, String email) {
        return new Customer(firstName, lastName, email);
    }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = Utils.requireEmail(email); }

    public String getFullName() { return fullName(); }

    @Override
    public String toString() {
        return "Customer{fullName='%s', email='%s'}".formatted(fullName(), email);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer customer)) return false;
        return Objects.equals(email, customer.email);
    }

    @Override
    public int hashCode() { return Objects.hash(email); }
}
