package ua.util;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/**
 * package-private helper (no 'public' modifier).
 * Visible only inside package ua.util.
 */
class ValidationHelper {
    // Java string literals require escaping backslashes (\\s, \\.).
    // This is a simple sanity-check regex (not a full RFC email parser).
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    static String requireNonBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
        return value.trim();
    }

    static <T> T requireNonNull(T value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " must not be null");
        }
        return value;
    }

    static String requireEmail(String email) {
        String e = requireNonBlank(email, "email");
        if (!EMAIL.matcher(e).matches()) {
            throw new IllegalArgumentException("email is not valid: " + email);
        }
        return e;
    }

    static BigDecimal requireNonNegative(BigDecimal value, String fieldName) {
        requireNonNull(value, fieldName);
        if (value.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException(fieldName + " must be >= 0");
        }
        return value;
    }

    static BigDecimal requirePositive(BigDecimal value, String fieldName) {
        requireNonNull(value, fieldName);
        if (value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException(fieldName + " must be > 0");
        }
        return value;
    }

    static BigDecimal requireRatePercent(BigDecimal value, String fieldName) {
        requireNonNull(value, fieldName);
        if (value.compareTo(BigDecimal.ZERO) <= 0 || value.compareTo(new BigDecimal("100")) > 0) {
            throw new IllegalArgumentException(fieldName + " must be in (0..100]");
        }
        return value;
    }

    static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }
}
