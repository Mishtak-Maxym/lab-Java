package ua.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

/**
 * Public facade that uses package-private ValidationHelper.
 */
public final class Utils {
    private Utils() {}

    public static String requireNonBlank(String value, String fieldName) {
        return ValidationHelper.requireNonBlank(value, fieldName);
    }

    public static <T> T requireNonNull(T value, String fieldName) {
        return ValidationHelper.requireNonNull(value, fieldName);
    }

    public static String requireEmail(String email) {
        return ValidationHelper.requireEmail(email);
    }

    public static BigDecimal requireNonNegative(BigDecimal value, String fieldName) {
        return ValidationHelper.requireNonNegative(value, fieldName);
    }

    public static BigDecimal requirePositive(BigDecimal value, String fieldName) {
        return ValidationHelper.requirePositive(value, fieldName);
    }

    public static BigDecimal requireRatePercent(BigDecimal value, String fieldName) {
        return ValidationHelper.requireRatePercent(value, fieldName);
    }

    public static void require(boolean condition, String message) {
        ValidationHelper.require(condition, message);
    }

    public static BigDecimal money(BigDecimal value) {
        requireNonNull(value, "money");
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    public static String formatMoney(BigDecimal value) {
        return money(value).toPlainString();
    }

    public static LocalDateTime now() {
        return LocalDateTime.now();
    }
}
