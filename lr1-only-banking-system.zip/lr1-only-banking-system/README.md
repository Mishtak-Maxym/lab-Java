# ЛР1: Основи Java та модифікатори доступу (Variant 11 — Banking System)

## Що реалізовано
- Не менше трьох класів (Account, Customer, Transaction, Loan, Branch + базові класи)
- Пакет `ua.util`:
  - `ValidationHelper` — package-private
  - `Utils` — public, використовує `ValidationHelper`
- Модифікатори доступу:
  - `private` — поля моделей
  - `public` — конструктори, getters/setters, основні методи
  - `protected` — поля базового класу `Person`
  - package-private — допоміжний клас `AccountNumberNormalizer` і метод `Loan.internalAuditInfo()`
- `toString()`, `equals()`, `hashCode()`
- static factory-методи (`of()`, `open()`, `deposit()` тощо)
- Валідація даних у конструкторах/сеттерах (`IllegalArgumentException`)
- `Main` демонструє успішні та неуспішні сценарії

## Запуск без Maven (Windows PowerShell)
У корені проєкту:
```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java | % FullName)
java -cp out ua.bank.model.Main
```

## Запуск з Maven
```bash
mvn -q -DskipTests package
```
