# ЛР2: Enum, Record та Switch-case (Variant 11 — Banking System)

## Вимоги, які покриті
- Є enum для властивостей об'єктів:
  - `AccountType { CHECKING, SAVINGS, CREDIT }`
  - `TransactionType { DEPOSIT, WITHDRAWAL, TRANSFER, PAYMENT }`
- Моделі перероблені на `record`:
  - `Customer`, `Branch`, `Account`, `Transaction`, `Loan`
- Використано `switch` **statement** і `switch` **expression** (Java 14+):
  - `BankingProcessor.apply()` (switch expressions з `yield`)
  - `BankingProcessor.legacyCategory()` (класичний switch-case)
- Демонстраційний клас `Main`:
  - створює records/enums
  - обробляє транзакції
  - показує успішні та неуспішні сценарії валідації

## Де код
- `src/main/java/ua/bank/model/lab2/*`

## Запуск (JDK 17 рекомендовано)
### Windows PowerShell
```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java | % FullName)
java -cp out ua.bank.model.lab2.Main
```

### Maven
```bash
mvn -q -DskipTests package
```
