package ua.bank.model.lab2;

/**
 * ЛР2: enum для типу рахунку.
 */
public enum AccountType {
    CHECKING,
    SAVINGS,
    CREDIT
}
