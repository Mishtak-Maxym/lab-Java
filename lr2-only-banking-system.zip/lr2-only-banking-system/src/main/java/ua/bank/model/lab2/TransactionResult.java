package ua.bank.model.lab2;

/**
 * ЛР2: результат застосування транзакції.
 *
 * fromUpdated/toUpdated можуть бути null для DEPOSIT/WITHDRAWAL.
 */
public record TransactionResult(Transaction transaction,
                                Account fromUpdated,
                                Account toUpdated,
                                double fee,
                                String message) {
}
