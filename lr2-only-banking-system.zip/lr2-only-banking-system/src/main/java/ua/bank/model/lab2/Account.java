package ua.bank.model.lab2;

import ua.util.Utils;

/**
 * ЛР2: Account як record.
 *
 * Іммутабельний: будь-яка операція повертає НОВИЙ Account.
 */
public record Account(String accountNumber, Customer owner, AccountType type, double balance) {

    public Account {
        accountNumber = Utils.requireNonBlank(normalize(accountNumber), "accountNumber");
        owner = Utils.requireNonNull(owner, "owner");
        type = Utils.requireNonNull(type, "type");

        double minAllowed = switch (type) {
            case CREDIT -> -10_000.0;  // для прикладу: кредит може йти "в мінус"
            case CHECKING, SAVINGS -> 0.0;
        };

        if (balance < minAllowed) {
            throw new IllegalArgumentException(
                    "balance must be >= " + minAllowed + " for type=" + type + ", got: " + balance
            );
        }
    }

    public static Account checking(String accountNumber, Customer owner, double balance) {
        return new Account(accountNumber, owner, AccountType.CHECKING, balance);
    }

    public static Account savings(String accountNumber, Customer owner, double balance) {
        return new Account(accountNumber, owner, AccountType.SAVINGS, balance);
    }

    public static Account credit(String accountNumber, Customer owner, double balance) {
        return new Account(accountNumber, owner, AccountType.CREDIT, balance);
    }

    public Account deposit(double amount) {
        validatePositive(amount, "amount");
        return new Account(accountNumber, owner, type, balance + amount);
    }

    public Account withdraw(double amount) {
        validatePositive(amount, "amount");

        double newBalance = balance - amount;
        double minAllowed = switch (type) {
            case CREDIT -> -10_000.0;
            case CHECKING, SAVINGS -> 0.0;
        };
        if (newBalance < minAllowed) {
            throw new IllegalArgumentException(
                    "Insufficient funds. min=" + minAllowed + ", balance=" + balance + ", amount=" + amount
            );
        }
        return new Account(accountNumber, owner, type, newBalance);
    }

    private static void validatePositive(double value, String name) {
        if (!(value > 0.0)) {
            throw new IllegalArgumentException(name + " must be > 0, got: " + value);
        }
    }

    private static String normalize(String accountNumber) {
        if (accountNumber == null) return null;
        // прибираємо пробіли/дефіси (демо структуризації даних)
        return accountNumber.replaceAll("[\\s-]", "");
    }
}
