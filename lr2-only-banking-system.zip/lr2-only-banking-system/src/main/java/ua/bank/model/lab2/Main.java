package ua.bank.model.lab2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * ЛР2: Enum, Record та Switch-case.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("=== LR2: Enum, Record & Switch-case ===");

        // 1) створення record + enum
        Customer alice = Customer.of("Alice", "Koval", "alice@example.com");
        Customer bob = Customer.of("Bob", "Shevchenko", "bob@example.com");
        Branch branch = Branch.of("Central", "Kyiv");

        System.out.println("Customer (record): " + alice);
        System.out.println("Branch (record): " + branch);

        Account a1 = Account.checking("UA-001 111-222", alice, 5000);
        Account a2 = Account.savings("UA-002-333-444", bob, 1200);
        Account credit = Account.credit("UA-CR-999", alice, -200); // CREDIT може бути "в мінус"

        System.out.println("\nAccounts:");
        System.out.println("  " + a1);
        System.out.println("  " + a2);
        System.out.println("  " + credit);

        // 2) приклади switch-case / switch expressions на транзакціях
        List<Transaction> txs = new ArrayList<>();
        txs.add(Transaction.deposit(a1, 300));
        txs.add(Transaction.withdrawal(a2, 100));
        txs.add(Transaction.transfer(a1, a2, 250));
        txs.add(Transaction.payment(a1, credit, 400));

        System.out.println("\nTransactions & processing:");
        for (Transaction tx : txs) {
            System.out.println("\n---");
            System.out.println("TX: " + tx.type() + ", category(legacy switch)=" + BankingProcessor.legacyCategory(tx.type()));
            TransactionResult result = BankingProcessor.apply(tx);
            System.out.println("Fee (switch expression): " + result.fee());
            System.out.println("Message: " + result.message());
            System.out.println("Updated from: " + result.fromUpdated());
            System.out.println("Updated to  : " + result.toUpdated());
        }

        // 3) ще один приклад: Loan + switch expression
        Loan loan = Loan.of(alice, 10_000, 18.0, LocalDate.now(), InterestMode.COMPOUND);
        System.out.println("\nLoan: " + loan);
        System.out.println("Total to pay in 12 months (switch expression): " + loan.totalToPay(12));

        // 4) неуспішні сценарії (валідація)
        System.out.println("\nValidation failures (expected):");
        try {
            Customer badEmail = Customer.of("Ivan", "Test", "not-an-email");
            System.out.println(badEmail);
        } catch (IllegalArgumentException ex) {
            System.out.println("Bad email -> " + ex.getMessage());
        }

        try {
            Transaction badAmount = Transaction.deposit(a1, -50);
            System.out.println(badAmount);
        } catch (IllegalArgumentException ex) {
            System.out.println("Bad amount -> " + ex.getMessage());
        }

        try {
            // SAVINGS не може піти в мінус
            Account badBalance = Account.savings("UA-003", alice, -1);
            System.out.println(badBalance);
        } catch (IllegalArgumentException ex) {
            System.out.println("Bad balance -> " + ex.getMessage());
        }
    }
}
