package ua.bank.model.lab2;

public class MainLab2 {
    public static void main(String[] args) {
        System.out.println("=== LR2 demo: records ===");
        Customer c = Customer.of("Oleh", "Ivanenko", "oleh@ex.ua");
        Branch b = Branch.of("Downtown", "Lviv");
        System.out.println(c);
        System.out.println("Full name: " + c.fullName());
        System.out.println(b);
    }
}
