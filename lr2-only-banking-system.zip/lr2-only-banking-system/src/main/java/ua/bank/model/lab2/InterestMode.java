package ua.bank.model.lab2;

/**
 * Додатковий enum (ЛР2): як нараховується відсоток.
 */
public enum InterestMode {
    SIMPLE,
    COMPOUND
}
