package ua.bank.model.lab2;

import ua.util.Utils;

/**
 * ЛР2: Customer as record.
 */
public record Customer(String firstName, String lastName, String email) {
    public Customer {
        firstName = Utils.requireNonBlank(firstName, "firstName");
        lastName = Utils.requireNonBlank(lastName, "lastName");
        email = Utils.requireEmail(email);
    }

    public static Customer of(String firstName, String lastName, String email) {
        return new Customer(firstName, lastName, email);
    }

    public String fullName() { return firstName + " " + lastName; }
}
