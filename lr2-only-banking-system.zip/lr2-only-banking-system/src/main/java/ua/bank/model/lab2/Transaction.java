package ua.bank.model.lab2;

import ua.util.Utils;

import java.time.LocalDateTime;

/**
 * ЛР2: Transaction як record.
 *
 * Валідація залежить від TransactionType.
 */
public record Transaction(Account fromAccount,
                          Account toAccount,
                          double amount,
                          LocalDateTime date,
                          TransactionType type) {

    public Transaction {
        type = Utils.requireNonNull(type, "type");
        date = Utils.requireNonNull(date, "date");

        if (!(amount > 0.0)) {
            throw new IllegalArgumentException("amount must be > 0, got: " + amount);
        }

        // switch-case для перевірки структури транзакції
        switch (type) {
            case DEPOSIT -> {
                if (toAccount == null) throw new IllegalArgumentException("DEPOSIT requires toAccount");
            }
            case WITHDRAWAL -> {
                if (fromAccount == null) throw new IllegalArgumentException("WITHDRAWAL requires fromAccount");
            }
            case TRANSFER, PAYMENT -> {
                if (fromAccount == null || toAccount == null) {
                    throw new IllegalArgumentException(type + " requires fromAccount and toAccount");
                }
                if (fromAccount.accountNumber().equals(toAccount.accountNumber())) {
                    throw new IllegalArgumentException(type + " requires different accounts");
                }
            }
        }
    }

    // ===== factory methods =====

    public static Transaction deposit(Account to, double amount) {
        return new Transaction(null, to, amount, LocalDateTime.now(), TransactionType.DEPOSIT);
    }

    public static Transaction withdrawal(Account from, double amount) {
        return new Transaction(from, null, amount, LocalDateTime.now(), TransactionType.WITHDRAWAL);
    }

    public static Transaction transfer(Account from, Account to, double amount) {
        return new Transaction(from, to, amount, LocalDateTime.now(), TransactionType.TRANSFER);
    }

    public static Transaction payment(Account from, Account to, double amount) {
        return new Transaction(from, to, amount, LocalDateTime.now(), TransactionType.PAYMENT);
    }
}
