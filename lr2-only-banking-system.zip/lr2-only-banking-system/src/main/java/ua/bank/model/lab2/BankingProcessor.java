package ua.bank.model.lab2;

/**
 * ЛР2: приклад "обробника" (utility-class), що використовує switch-case/switch expression.
 */
public final class BankingProcessor {
    private BankingProcessor() {}

    /**
     * Застосувати транзакцію й повернути оновлені рахунки (records).
     */
    public static TransactionResult apply(Transaction tx) {
        // switch expression: комісія залежить від типу транзакції
        double fee = switch (tx.type()) {
            case TRANSFER -> 1.00;
            case PAYMENT -> 0.50;
            case DEPOSIT, WITHDRAWAL -> 0.00;
        };

        return switch (tx.type()) {
            case DEPOSIT -> {
                Account updatedTo = tx.toAccount().deposit(tx.amount());
                yield new TransactionResult(tx, null, updatedTo, fee, "Deposit applied");
            }
            case WITHDRAWAL -> {
                Account updatedFrom = tx.fromAccount().withdraw(tx.amount());
                yield new TransactionResult(tx, updatedFrom, null, fee, "Withdrawal applied");
            }
            case TRANSFER -> {
                Account updatedFrom = tx.fromAccount().withdraw(tx.amount() + fee);
                Account updatedTo = tx.toAccount().deposit(tx.amount());
                yield new TransactionResult(tx, updatedFrom, updatedTo, fee, "Transfer applied (fee included)");
            }
            case PAYMENT -> {
                // PAYMENT: списання з from + комісія, зарахування на to
                Account updatedFrom = tx.fromAccount().withdraw(tx.amount() + fee);
                Account updatedTo = tx.toAccount().deposit(tx.amount());
                yield new TransactionResult(tx, updatedFrom, updatedTo, fee, "Payment applied (fee included)");
            }
        };
    }

    /**
     * Приклад КЛАСИЧНОГО switch-case (statement) з break.
     */
    public static String legacyCategory(TransactionType type) {
        String category;
        switch (type) {
            case DEPOSIT:
            case WITHDRAWAL:
                category = "CASH";
                break;
            case TRANSFER:
            case PAYMENT:
                category = "NON_CASH";
                break;
            default:
                category = "UNKNOWN";
        }
        return category;
    }
}
