package ua.bank.model.lab2;

/**
 * ЛР2: enum для типу транзакції.
 */
public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER,
    PAYMENT
}
