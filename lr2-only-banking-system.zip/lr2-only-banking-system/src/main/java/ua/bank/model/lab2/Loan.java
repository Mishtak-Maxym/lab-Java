package ua.bank.model.lab2;

import ua.util.Utils;

import java.time.LocalDate;

/**
 * ЛР2: Loan як record.
 */
public record Loan(Customer customer,
                   double amount,
                   double interestRatePercent,
                   LocalDate startDate,
                   InterestMode interestMode) {

    public Loan {
        customer = Utils.requireNonNull(customer, "customer");
        startDate = Utils.requireNonNull(startDate, "startDate");
        interestMode = Utils.requireNonNull(interestMode, "interestMode");

        if (!(amount > 0.0)) {
            throw new IllegalArgumentException("amount must be > 0, got: " + amount);
        }
        if (!(interestRatePercent > 0.0 && interestRatePercent <= 100.0)) {
            throw new IllegalArgumentException("interestRatePercent must be in (0;100], got: " + interestRatePercent);
        }
    }

    public static Loan of(Customer customer, double amount, double ratePercent, LocalDate startDate, InterestMode mode) {
        return new Loan(customer, amount, ratePercent, startDate, mode);
    }

    /**
     * Порахувати орієнтовну суму до сплати через N місяців.
     * Використано switch expression (Java 14+).
     */
    public double totalToPay(int months) {
        if (months <= 0) throw new IllegalArgumentException("months must be > 0");

        double r = interestRatePercent / 100.0;
        return switch (interestMode) {
            case SIMPLE -> amount * (1.0 + r * (months / 12.0));
            case COMPOUND -> amount * Math.pow(1.0 + r / 12.0, months);
        };
    }
}
