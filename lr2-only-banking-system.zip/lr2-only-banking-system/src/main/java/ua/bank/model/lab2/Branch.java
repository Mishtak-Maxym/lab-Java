package ua.bank.model.lab2;

import ua.util.Utils;

/**
 * ЛР2: Branch as record.
 */
public record Branch(String name, String location) {
    public Branch {
        name = Utils.requireNonBlank(name, "name");
        location = Utils.requireNonBlank(location, "location");
    }

    public static Branch of(String name, String location) {
        return new Branch(name, location);
    }
}
