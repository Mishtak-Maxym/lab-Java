package ua.bank.model;

import ua.util.Utils;

public class VipCustomer extends Customer {
    private int level;

    public VipCustomer(String firstName, String lastName, String email, int level) {
        super(firstName, lastName, email);
        setLevel(level);
    }

    public static VipCustomer of(String firstName, String lastName, String email, int level) {
        return new VipCustomer(firstName, lastName, email, level);
    }

    public int getLevel() { return level; }

    public void setLevel(int level) {
        Utils.require(level >= 1 && level <= 10, "level must be in [1..10]");
        this.level = level;
    }

    public String vipLabel() {
        return "VIP-" + level + ": " + firstName + " " + lastName;
    }

    @Override
    public String toString() {
        return "VipCustomer{label='%s', email='%s'}".formatted(vipLabel(), getEmail());
    }
}
