package ua.bank.model;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL, TRANSFER, PAYMENT
}
