package ua.bank.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import ua.util.Utils;

public class Transaction {
    private final TransactionType type;
    private final Account fromAccount;
    private final Account toAccount;
    private final BigDecimal amount;
    private final LocalDateTime date;

    private Transaction(TransactionType type, Account fromAccount, Account toAccount, BigDecimal amount, LocalDateTime date) {
        this.type = Utils.requireNonNull(type, "type");
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = Utils.money(Utils.requirePositive(amount, "amount"));
        this.date = Utils.requireNonNull(date, "date");

        switch (type) {
            case DEPOSIT -> Utils.require(toAccount != null && fromAccount == null, "DEPOSIT requires toAccount and no fromAccount");
            case WITHDRAWAL -> Utils.require(fromAccount != null && toAccount == null, "WITHDRAWAL requires fromAccount and no toAccount");
            case TRANSFER, PAYMENT -> Utils.require(fromAccount != null && toAccount != null, type + " requires both accounts");
        }
    }

    public static Transaction deposit(Account to, BigDecimal amount) {
        return new Transaction(TransactionType.DEPOSIT, null, Utils.requireNonNull(to, "toAccount"), amount, Utils.now());
    }

    public static Transaction withdraw(Account from, BigDecimal amount) {
        return new Transaction(TransactionType.WITHDRAWAL, Utils.requireNonNull(from, "fromAccount"), null, amount, Utils.now());
    }

    public static Transaction transfer(Account from, Account to, BigDecimal amount) {
        return new Transaction(TransactionType.TRANSFER, Utils.requireNonNull(from, "fromAccount"), Utils.requireNonNull(to, "toAccount"), amount, Utils.now());
    }

    public static Transaction payment(Account from, Account to, BigDecimal amount) {
        return new Transaction(TransactionType.PAYMENT, Utils.requireNonNull(from, "fromAccount"), Utils.requireNonNull(to, "toAccount"), amount, Utils.now());
    }

    public TransactionType getType() { return type; }
    public Account getFromAccount() { return fromAccount; }
    public Account getToAccount() { return toAccount; }
    public BigDecimal getAmount() { return amount; }
    public LocalDateTime getDate() { return date; }

    @Override
    public String toString() {
        String from = (fromAccount == null) ? "-" : fromAccount.getAccountNumber();
        String to = (toAccount == null) ? "-" : toAccount.getAccountNumber();
        return "Transaction{type=%s, from='%s', to='%s', amount=%s, date=%s}"
                .formatted(type, from, to, Utils.formatMoney(amount), date);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Transaction that)) return false;
        return type == that.type
                && Objects.equals(fromAccount, that.fromAccount)
                && Objects.equals(toAccount, that.toAccount)
                && Objects.equals(amount, that.amount)
                && Objects.equals(date, that.date);
    }

    @Override
    public int hashCode() { return Objects.hash(type, fromAccount, toAccount, amount, date); }
}
