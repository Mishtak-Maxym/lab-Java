package ua.bank.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import ua.util.Utils;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== LR1 Variant 11: Banking System ===");

        Customer alice = new Customer("Alice", "Brown", "alice@example.com");
        Customer bob = Customer.of("Bob", "Stone", "bob@example.com");
        VipCustomer vip = VipCustomer.of("Vira", "Koval", "vira@vip.ua", 3);

        Branch mainBranch = Branch.of("Main Branch", "Kyiv");
        System.out.println("Branch: " + mainBranch);

        String normalized = AccountNumberNormalizer.normalize(" ua- 001-xy ");
        System.out.println("Normalized account number: " + normalized);

        Account a1 = Account.openChecking("ua-001-xy", alice, new BigDecimal("1000"));
        Account a2 = Account.open("UA 002 ZZ", bob, AccountType.SAVINGS, new BigDecimal("250.50"));

        System.out.println("Account #1: " + a1);
        System.out.println("Account #2: " + a2);

        System.out.println("Formatted money: " + Utils.formatMoney(new BigDecimal("10")));

        Transaction t1 = a1.deposit(new BigDecimal("200"));
        Transaction t2 = a1.transferTo(a2, new BigDecimal("150.25"));
        Transaction t3 = a2.withdraw(new BigDecimal("50"));

        System.out.println(t1);
        System.out.println(t2);
        System.out.println(t3);

        System.out.println("Balances after ops:");
        System.out.println(" a1=" + Utils.formatMoney(a1.getBalance()));
        System.out.println(" a2=" + Utils.formatMoney(a2.getBalance()));

        Loan loan = Loan.of(alice, new BigDecimal("5000"), new BigDecimal("12.5"), LocalDate.now());
        System.out.println(loan);
        System.out.println("Estimated 1y interest: " + Utils.formatMoney(loan.estimateOneYearInterest()));
        System.out.println("Internal audit info (package-private): " + loan.internalAuditInfo());

        System.out.println("Access protected (same package): vip.firstName=" + vip.firstName);
        System.out.println("Vip label (subclass protected access): " + vip.vipLabel());

        System.out.println("\n--- Failed scenarios ---");
        try {
            Customer bad = new Customer("", "X", "nope");
            System.out.println(bad);
        } catch (IllegalArgumentException ex) {
            System.out.println("Expected error: " + ex.getMessage());
        }

        try {
            a1.withdraw(new BigDecimal("999999"));
        } catch (IllegalArgumentException ex) {
            System.out.println("Expected error: " + ex.getMessage());
        }

        try {
            Account.open("  ", alice, AccountType.CHECKING, BigDecimal.ZERO);
        } catch (IllegalArgumentException ex) {
            System.out.println("Expected error: " + ex.getMessage());
        }

        try {
            VipCustomer.of("Taras", "", "taras@example.com", 99);
        } catch (IllegalArgumentException ex) {
            System.out.println("Expected error: " + ex.getMessage());
        }

        System.out.println("\nDone.");
    }
}
