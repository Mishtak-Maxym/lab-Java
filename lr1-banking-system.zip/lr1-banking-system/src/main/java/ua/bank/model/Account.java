package ua.bank.model;

import java.math.BigDecimal;
import java.util.Objects;
import ua.util.Utils;

public class Account {
    private final String accountNumber;
    private final Customer owner;
    private final AccountType type;

    protected BigDecimal balance;

    public Account(String accountNumber, Customer owner, AccountType type, BigDecimal initialBalance) {
        this.accountNumber = AccountNumberNormalizer.normalize(accountNumber);
        this.owner = Utils.requireNonNull(owner, "owner");
        this.type = Utils.requireNonNull(type, "type");
        this.balance = Utils.money(Utils.requireNonNegative(initialBalance, "initialBalance"));
    }

    public static Account open(String accountNumber, Customer owner, AccountType type, BigDecimal initialBalance) {
        return new Account(accountNumber, owner, type, initialBalance);
    }

    public static Account openChecking(String accountNumber, Customer owner, BigDecimal initialBalance) {
        return open(accountNumber, owner, AccountType.CHECKING, initialBalance);
    }

    public static Account openSavings(String accountNumber, Customer owner, BigDecimal initialBalance) {
        return open(accountNumber, owner, AccountType.SAVINGS, initialBalance);
    }

    public String getAccountNumber() { return accountNumber; }
    public Customer getOwner() { return owner; }
    public AccountType getType() { return type; }
    public BigDecimal getBalance() { return balance; }

    public Transaction deposit(BigDecimal amount) {
        BigDecimal a = Utils.money(Utils.requirePositive(amount, "amount"));
        applyDelta(a);
        return Transaction.deposit(this, a);
    }

    public Transaction withdraw(BigDecimal amount) {
        BigDecimal a = Utils.money(Utils.requirePositive(amount, "amount"));
        Utils.require(balance.compareTo(a) >= 0, "Not enough balance for withdrawal");
        applyDelta(a.negate());
        return Transaction.withdraw(this, a);
    }

    public Transaction transferTo(Account to, BigDecimal amount) {
        Utils.requireNonNull(to, "toAccount");
        BigDecimal a = Utils.money(Utils.requirePositive(amount, "amount"));
        Utils.require(balance.compareTo(a) >= 0, "Not enough balance for transfer");
        applyDelta(a.negate());
        to.applyDelta(a);
        return Transaction.transfer(this, to, a);
    }

    protected void applyDelta(BigDecimal delta) {
        this.balance = Utils.money(this.balance.add(delta));
    }

    @Override
    public String toString() {
        return "Account{accountNumber='%s', owner='%s', type=%s, balance=%s}"
                .formatted(accountNumber, owner.getFullName(), type, Utils.formatMoney(balance));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Account account)) return false;
        return Objects.equals(accountNumber, account.accountNumber);
    }

    @Override
    public int hashCode() { return Objects.hash(accountNumber); }
}
