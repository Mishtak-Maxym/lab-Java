package ua.bank.model;

public enum AccountType {
    CHECKING, SAVINGS, CREDIT
}
