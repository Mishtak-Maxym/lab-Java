package ua.bank.model;

import ua.util.Utils;

/**
 * package-private class (no modifier) to demonstrate access in Main (same package).
 */
class AccountNumberNormalizer {
    static String normalize(String raw) {
        String v = Utils.requireNonBlank(raw, "accountNumber");
        return v.replaceAll("[\s-]", "").toUpperCase();
    }
}
