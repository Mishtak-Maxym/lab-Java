# ЛР1 (Варіант 11): Banking System — Java OOP + Access Modifiers

Цей проєкт містить реалізацію для **ЛР1** (класи) та приклад для **ЛР2** (records).

## Структура
- `ua.util`
  - `ValidationHelper` — **package-private** (без модифікатора), містить методи валідації
  - `Utils` — **public**, використовує `ValidationHelper`
- `ua.bank.model` — основні моделі (ЛР1)
  - `Person` (abstract) — приклад **protected** полів/методів
  - `Customer`, `Branch`, `Account`, `Transaction`, `Loan`
  - `AccountType`, `TransactionType` — enum
  - `AccountNumberNormalizer` — **package-private** клас (демонстрація доступу)
  - `Main` — демонстрація сценаріїв (успішні/неуспішні), protected/package-private
- `ua.bank.model.lab2` — приклад для ЛР2 (records)
  - `Customer` — record
  - `Branch` — record
  - `MainLab2` — короткий демо

## Як запустити (без Maven)
> Якщо у вас немає Maven — можна зібрати через `javac`.

**Windows (PowerShell):**
```powershell
cd lr1-banking-system
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java | % FullName)
java -cp out ua.bank.model.Main
java -cp out ua.bank.model.lab2.MainLab2
```

## GitHub (завантаження)
```bash
git init
git add .
git commit -m "LR1 Banking System (variant 11)"
git branch -M main
git remote add origin <URL_ВАШОГО_REPO>
git push -u origin main
```
