package ua.example.lab5;

import org.junit.jupiter.api.Test;
import ua.example.lab5.model.Group;
import ua.example.lab5.repo.GroupRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class GroupRepositorySortTest {

    private GroupRepository repoWithSample() {
        GroupRepository repo = new GroupRepository();
        repo.add(new Group("KN-21", "Computer Networks", 2));
        repo.add(new Group("SE-11", "Software Engineering", 1));
        repo.add(new Group("AI-31", "Artificial Intelligence", 3));
        return repo;
    }

    @Test
    void sortByIdentityAsc() {
        GroupRepository repo = repoWithSample();
        repo.sortByIdentity("ASC");

        List<String> codes = repo.getAll().stream().map(Group::code).toList();
        assertEquals(List.of("AI-31", "KN-21", "SE-11"), codes);
    }

    @Test
    void sortByYearDesc() {
        GroupRepository repo = repoWithSample();
        repo.sortByYear("DESC");

        List<Integer> years = repo.getAll().stream().map(Group::year).toList();
        assertEquals(List.of(3, 2, 1), years);
    }
}
