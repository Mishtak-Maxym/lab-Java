package ua.example.lab5;

import org.junit.jupiter.api.Test;
import ua.example.lab5.model.Student;
import ua.example.lab5.model.StudyForm;
import ua.example.lab5.repo.StudentRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StudentRepositorySortTest {

    private StudentRepository repoWithSample() {
        StudentRepository repo = new StudentRepository();
        repo.add(new Student(3L, "Max", "Ivanov", 19, 88.5, StudyForm.FULL_TIME, "SE-11"));
        repo.add(new Student(1L, "Anna", "Shevchenko", 18, 92.0, StudyForm.PART_TIME, "KN-21"));
        repo.add(new Student(2L, "Oleh", "Bondar", 20, 75.0, StudyForm.FULL_TIME, "AI-31"));
        repo.add(new Student(4L, "Ira", "bondar", 18, 81.0, StudyForm.FULL_TIME, "AI-31"));
        return repo;
    }

    @Test
    void sortByIdentityAsc() {
        StudentRepository repo = repoWithSample();
        repo.sortByIdentity("ASC");

        List<Long> ids = repo.getAll().stream().map(Student::id).toList();
        assertEquals(List.of(1L, 2L, 3L, 4L), ids);
    }

    @Test
    void sortByIdentityDesc() {
        StudentRepository repo = repoWithSample();
        repo.sortByIdentity("DESC");

        List<Long> ids = repo.getAll().stream().map(Student::id).toList();
        assertEquals(List.of(4L, 3L, 2L, 1L), ids);
    }

    @Test
    void sortByLastNameAsc_caseInsensitive() {
        StudentRepository repo = repoWithSample();
        repo.sortByLastName("ASC");

        List<String> lastNames = repo.getAll().stream().map(Student::lastName).toList();
        // "Bondar" і "bondar" рівні без врахування регістру, тому далі сортуємо за ім'ям (Ira перед Oleh)
        assertEquals(List.of("bondar", "Bondar", "Ivanov", "Shevchenko"), lastNames);
    }

    @Test
    void sortByGpaDesc() {
        StudentRepository repo = repoWithSample();
        repo.sortByGpa("DESC");

        List<Double> gpas = repo.getAll().stream().map(Student::gpa).toList();
        assertEquals(List.of(92.0, 88.5, 81.0, 75.0), gpas);
    }

    @Test
    void invalidOrder_throws() {
        StudentRepository repo = repoWithSample();
        assertThrows(IllegalArgumentException.class, () -> repo.sortByIdentity("UP"));
        assertThrows(IllegalArgumentException.class, () -> repo.sortByGpa("down"));
    }
}
