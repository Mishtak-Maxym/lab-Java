package ua.example.lab5.repo;

import ua.example.lab5.common.GenericRepository;
import ua.example.lab5.model.Student;

import java.util.Comparator;

public class StudentRepository extends GenericRepository<Student, Long> {

    public void sortByLastName(String order) {
        sort(Student.BY_LAST_NAME, order);
        logger.info(() -> "SORT_STUDENTS_BY_LAST_NAME order=" + order);
    }

    public void sortByFirstName(String order) {
        sort(Student.BY_FIRST_NAME, order);
        logger.info(() -> "SORT_STUDENTS_BY_FIRST_NAME order=" + order);
    }

    public void sortByAge(String order) {
        sort(Student.BY_AGE, order);
        logger.info(() -> "SORT_STUDENTS_BY_AGE order=" + order);
    }

    public void sortByGpa(String order) {
        sort(Student.BY_GPA, order);
        logger.info(() -> "SORT_STUDENTS_BY_GPA order=" + order);
    }

    public void sortByGroupCode(String order) {
        sort(Student.BY_GROUP_CODE, order);
        logger.info(() -> "SORT_STUDENTS_BY_GROUP_CODE order=" + order);
    }

    public void sortByFormThenGpa(String order) {
        // Lambda + thenComparingDouble + method references
        Comparator<Student> cmp = Comparator
                .comparing(Student::form)
                .thenComparingDouble(Student::gpa)
                .thenComparing(Student::id);

        sort(cmp, order);
        logger.info(() -> "SORT_STUDENTS_BY_FORM_THEN_GPA order=" + order);
    }
}
