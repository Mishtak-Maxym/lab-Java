package ua.example.lab5.common;

public interface Identifiable<K extends Comparable<K>> {
    K getIdentity();
}
