package ua.example.lab5.model;

public enum StudyForm {
    FULL_TIME,
    PART_TIME
}
