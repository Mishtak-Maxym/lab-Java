package ua.example.lab5.common;

import java.util.*;
import java.util.logging.Logger;

public class GenericRepository<T extends Identifiable<K>, K extends Comparable<K>> {

    protected final Logger logger = Logger.getLogger(getClass().getName());
    protected final List<T> items = new ArrayList<>();

    public void add(T entity) {
        if (entity == null) throw new IllegalArgumentException("Entity must not be null");
        items.add(entity);
        logger.info(() -> "ADD: " + entity);
    }

    public void addAll(Collection<T> entities) {
        if (entities == null) throw new IllegalArgumentException("Entities must not be null");
        for (T e : entities) add(e);
    }

    public List<T> getAll() {
        return Collections.unmodifiableList(items);
    }

    /** Sort by identity (ASC/DESC). */
    public void sortByIdentity(String order) {
        Comparator<T> byId = (a, b) -> a.getIdentity().compareTo(b.getIdentity());
        sort(byId, order);
        logger.info(() -> "SORT_BY_IDENTITY order=" + normalizeOrder(order));
    }

    /** Helper sort used by child repositories. */
    protected void sort(Comparator<? super T> comparator, String order) {
        Objects.requireNonNull(comparator, "Comparator must not be null");
        String o = normalizeOrder(order);

        if ("DESC".equals(o)) {
            items.sort(comparator.reversed());
        } else {
            items.sort(comparator);
        }
    }

    private String normalizeOrder(String order) {
        if (order == null) return "ASC";
        String o = order.trim().toUpperCase(Locale.ROOT);
        if (o.isEmpty()) return "ASC";
        if (!o.equals("ASC") && !o.equals("DESC")) {
            throw new IllegalArgumentException("Order must be 'ASC' or 'DESC'");
        }
        return o;
    }
}
