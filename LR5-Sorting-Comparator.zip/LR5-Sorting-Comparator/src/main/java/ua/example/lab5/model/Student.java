package ua.example.lab5.model;

import ua.example.lab5.common.Identifiable;

import java.util.Comparator;
import java.util.Locale;

public record Student(
        Long id,
        String firstName,
        String lastName,
        int age,
        double gpa,
        StudyForm form,
        String groupCode
) implements Identifiable<Long>, Comparable<Student> {

    public Student {
        if (id == null || id <= 0) throw new IllegalArgumentException("id must be positive");
        if (firstName == null || firstName.isBlank()) throw new IllegalArgumentException("firstName is required");
        if (lastName == null || lastName.isBlank()) throw new IllegalArgumentException("lastName is required");
        if (age <= 0) throw new IllegalArgumentException("age must be positive");
        if (gpa < 0.0 || gpa > 100.0) throw new IllegalArgumentException("gpa must be in range [0..100]");
        if (form == null) throw new IllegalArgumentException("form is required");
        if (groupCode == null || groupCode.isBlank()) throw new IllegalArgumentException("groupCode is required");
    }

    @Override
    public Long getIdentity() {
        return id;
    }

    /** Main Comparable field: id */
    @Override
    public int compareTo(Student o) {
        return this.id.compareTo(o.id);
    }

    private static final Comparator<String> CI =
            (a, b) -> a.toLowerCase(Locale.ROOT).compareTo(b.toLowerCase(Locale.ROOT));

    public static final Comparator<Student> BY_LAST_NAME =
            Comparator.comparing(Student::lastName, CI)
                    .thenComparing(Student::firstName, CI)
                    .thenComparing(Student::id);

    public static final Comparator<Student> BY_FIRST_NAME =
            Comparator.comparing(Student::firstName, CI)
                    .thenComparing(Student::lastName, CI)
                    .thenComparing(Student::id);

    public static final Comparator<Student> BY_AGE =
            Comparator.comparingInt(Student::age)
                    .thenComparing(Student::id);

    public static final Comparator<Student> BY_GPA =
            Comparator.comparingDouble(Student::gpa)
                    .thenComparing(Student::id);

    public static final Comparator<Student> BY_GROUP_CODE =
            Comparator.comparing(Student::groupCode, CI)
                    .thenComparing(Student::id);

    public static final Comparator<Student> BY_STUDY_FORM =
            Comparator.comparing(Student::form)
                    .thenComparing(Student::id);
}
