package ua.example.lab5.repo;

import ua.example.lab5.common.GenericRepository;
import ua.example.lab5.model.Group;

public class GroupRepository extends GenericRepository<Group, String> {

    public void sortByTitle(String order) {
        sort(Group.BY_TITLE, order);
        logger.info(() -> "SORT_GROUPS_BY_TITLE order=" + order);
    }

    public void sortByYear(String order) {
        sort(Group.BY_YEAR, order);
        logger.info(() -> "SORT_GROUPS_BY_YEAR order=" + order);
    }

    public void sortByCodeLength(String order) {
        sort(Group.BY_CODE_LENGTH, order);
        logger.info(() -> "SORT_GROUPS_BY_CODE_LENGTH order=" + order);
    }
}
