package ua.example.lab5.model;

import ua.example.lab5.common.Identifiable;

import java.util.Comparator;
import java.util.Locale;

public record Group(
        String code,
        String title,
        int year
) implements Identifiable<String>, Comparable<Group> {

    public Group {
        if (code == null || code.isBlank()) throw new IllegalArgumentException("code is required");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("title is required");
        if (year <= 0) throw new IllegalArgumentException("year must be positive");
    }

    @Override
    public String getIdentity() {
        return code;
    }

    /** Main Comparable field: code */
    @Override
    public int compareTo(Group o) {
        return this.code.compareToIgnoreCase(o.code);
    }

    private static final Comparator<String> CI =
            (a, b) -> a.toLowerCase(Locale.ROOT).compareTo(b.toLowerCase(Locale.ROOT));

    public static final Comparator<Group> BY_TITLE =
            Comparator.comparing(Group::title, CI)
                    .thenComparing(Group::code, CI);

    public static final Comparator<Group> BY_YEAR =
            Comparator.comparingInt(Group::year)
                    .thenComparing(Group::code, CI);

    public static final Comparator<Group> BY_CODE_LENGTH =
            Comparator.comparingInt((Group g) -> g.code().length())
                    .thenComparing(Group::code, CI);
}
