package ua.example.lab5;

import ua.example.lab5.model.*;
import ua.example.lab5.repo.GroupRepository;
import ua.example.lab5.repo.StudentRepository;

import java.util.logging.*;

public class Main {

    public static void main(String[] args) {
        setupLogging();

        StudentRepository studentRepo = new StudentRepository();
        GroupRepository groupRepo = new GroupRepository();

        groupRepo.add(new Group("KN-21", "Computer Networks", 2));
        groupRepo.add(new Group("SE-11", "Software Engineering", 1));
        groupRepo.add(new Group("AI-31", "Artificial Intelligence", 3));

        studentRepo.add(new Student(3L, "Max", "Ivanov", 19, 88.5, StudyForm.FULL_TIME, "SE-11"));
        studentRepo.add(new Student(1L, "Anna", "Shevchenko", 18, 92.0, StudyForm.PART_TIME, "KN-21"));
        studentRepo.add(new Student(2L, "Oleh", "Bondar", 20, 75.0, StudyForm.FULL_TIME, "AI-31"));
        studentRepo.add(new Student(4L, "Ira", "bondar", 18, 81.0, StudyForm.FULL_TIME, "AI-31"));

        System.out.println("=== Groups (original) ===");
        groupRepo.getAll().forEach(System.out::println);

        groupRepo.sortByIdentity("ASC");
        System.out.println("\n=== Groups sorted by identity ASC ===");
        groupRepo.getAll().forEach(System.out::println);

        groupRepo.sortByTitle("DESC");
        System.out.println("\n=== Groups sorted by title DESC ===");
        groupRepo.getAll().forEach(System.out::println);

        System.out.println("\n=== Students (original) ===");
        studentRepo.getAll().forEach(System.out::println);

        studentRepo.sortByIdentity("ASC");
        System.out.println("\n=== Students sorted by identity ASC ===");
        studentRepo.getAll().forEach(System.out::println);

        studentRepo.sortByLastName("ASC");
        System.out.println("\n=== Students sorted by lastName ASC ===");
        studentRepo.getAll().forEach(System.out::println);

        studentRepo.sortByGpa("DESC");
        System.out.println("\n=== Students sorted by gpa DESC ===");
        studentRepo.getAll().forEach(System.out::println);

        studentRepo.sortByFormThenGpa("ASC");
        System.out.println("\n=== Students sorted by form then gpa ASC ===");
        studentRepo.getAll().forEach(System.out::println);
    }

    private static void setupLogging() {
        Logger root = Logger.getLogger("");
        for (Handler h : root.getHandlers()) root.removeHandler(h);

        ConsoleHandler ch = new ConsoleHandler();
        ch.setLevel(Level.INFO);
        ch.setFormatter(new SimpleFormatter());

        root.addHandler(ch);
        root.setLevel(Level.INFO);
    }
}
