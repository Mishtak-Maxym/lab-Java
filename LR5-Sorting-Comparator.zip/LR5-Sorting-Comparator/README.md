# LR5: Sorting objects (Comparable / Comparator)

## What is inside
- `Comparable<T>` implemented in `Student` (by `id`) and `Group` (by `code`).
- Extra `Comparator` критерії в кожній сутності.
- `GenericRepository<T>` має `sortByIdentity(String order)` (ASC/DESC).
- Специфічні репозиторії: `StudentRepository`, `GroupRepository` з методами сортування за різними критеріями.
- Лямбда-вирази та method reference для компараторів.
- Логування (java.util.logging).
- JUnit 5 тести для перевірки сортування.

## Run
- Tests: `mvn test`
- Demo: run `ua.example.lab5.Main` from IDE.

> Якщо у тебе інші сутності з попередніх ЛР — скажи назви класів та поля, я перероблю під твою модель.
